package com.onlinegasbooking.exception;

public class CylinderNotFoundException extends Exception {
      public CylinderNotFoundException(String msg) {
	   super(msg);
      }
}
