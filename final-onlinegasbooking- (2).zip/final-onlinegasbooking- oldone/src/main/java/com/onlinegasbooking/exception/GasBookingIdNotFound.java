package com.onlinegasbooking.exception;

public class GasBookingIdNotFound extends Exception {

	public GasBookingIdNotFound (String message) {
		super(message);
		
	}
  
}
